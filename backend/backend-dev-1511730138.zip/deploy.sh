#!/bin/sh

zappa deploy dev